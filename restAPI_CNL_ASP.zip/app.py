from restAPI.services import *

if __name__ == "__main__":
   print("* Starting web service...")
   app.run(host='0.0.0.0')